import React from 'react';

const NotFound = () => {
    return (
        <div>
            <h1>ERROR 404</h1>
        </div>
    );
};

export default NotFound;